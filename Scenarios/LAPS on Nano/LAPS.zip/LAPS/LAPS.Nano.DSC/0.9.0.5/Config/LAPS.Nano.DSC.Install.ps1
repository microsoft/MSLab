$ConfigData = @{
   AllNodes = @(
      @{ NodeName = "*" }
        )
}

Configuration LAPS_Nano_Install
{
   Param (
 
      [Parameter()]
      [ValidateSet("Present","Absent")]
      [String]$Ensure = "Present"
   )
   
   Import-DscResource -ModuleName LAPS.Nano.DSC -ModuleVersion '0.9.0.5'

   cLapsNanoInstall Install
   {
    ID="LAPS.Nano"
    Ensure = $Ensure
   }
    
}

LAPS_Nano_Install -ConfigurationData $ConfigData -Ensure Present
